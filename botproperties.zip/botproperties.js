Hooks.on('ready', () => {
    CONFIG.DND5E.weaponProperties['TR'] = 'Thrown (Revised)';
    CONFIG.DND5E.weaponProperties['SA1'] = 'Savage (1)';
    CONFIG.DND5E.weaponProperties['SA2'] = 'Savage (2)';
    CONFIG.DND5E.weaponProperties['SA3'] = 'Savage (3)';
    CONFIG.DND5E.weaponProperties['SA4'] = 'Savage (4)';
    CONFIG.DND5E.weaponProperties['SA5'] = 'Savage (5)';
    CONFIG.DND5E.weaponProperties['SA6'] = 'Savage (6)';
    CONFIG.DND5E.weaponProperties['PA1'] = 'Parry (1)';
    CONFIG.DND5E.weaponProperties['PA2'] = 'Parry (2)';
    CONFIG.DND5E.weaponProperties['RI'] = 'Riposte';
    CONFIG.DND5E.weaponProperties['SO'] = 'Short';
    CONFIG.DND5E.weaponProperties['LO'] = 'Long';
    CONFIG.DND5E.weaponProperties['BR'] = 'Brace';
    CONFIG.DND5E.weaponProperties['R5'] = 'Reach (5 ft.)';
    CONFIG.DND5E.weaponProperties['R10'] = 'Reach (10 ft.)';
    CONFIG.DND5E.weaponProperties['UW'] = 'Unwieldy';
    });